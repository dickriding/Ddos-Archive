#include "headers/main.h"
char *encode(char *str) {
	return str;
}
