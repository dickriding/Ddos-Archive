#include "headers/main.h"
char **str_split(char *buffer, char *delim, size_t *count)
{
    char **retargs, *token;
    retargs = malloc(1 * sizeof(char *));
    token = strtok_r(buffer, delim, &buffer);
    while (token)
    {
        retargs = realloc(retargs, (*count + 1) * sizeof(char *));
        retargs[(*count)++] = token;
        token = strtok_r(NULL, delim, &buffer);
    }
    return retargs;
}
int sendfd(int datafd, char *msg, ...)
{
    char buffer[MAXFDS];
    va_list arglist;
    va_start(arglist, msg);
    vsnprintf(buffer, MAXFDS, msg, arglist);
    va_end(arglist);
    return send(datafd, buffer, strlen(buffer), MSG_NOSIGNAL);
}
void sendfile(int datafd, const char *filename) {
    char filebuf[5000], editedBuf[5000];
    FILE *fp = fopen(filename, "r");
    if(fp == NULL) {
        printf("File error sendfile(%s)\n", filename);
        return;
    }
    while(fgets(filebuf, sizeof(filebuf), fp) != NULL) {
        sprintf(editedBuf, "%s", changeStr(filebuf));
        sendfd(datafd, "%s", editedBuf);
    }
    fclose(fp);
}
int SendLog(int datafd, char *file, char *msg, ...)
{
    char buffer[MAXFDS];
    va_list arglist;
    va_start(arglist, msg);
    vsnprintf(buffer, MAXFDS, msg, arglist);
    va_end(arglist);
    FILE *fp = fopen(file, "a+");
    fprintf(fp, "%s", buffer);
    fclose(fp);
    return 0;
}
char *changeStr(char *str)
{
    int len = strlen(str);
    char returnstring[(strlen(str) * 2) + 1];

    memset(filestring, 0, sizeof(filestring));
    memset(returnstring, 0, sizeof(returnstring));

    for(int i = 0; i < len; i++) {
        if(str[i] == '\\') {
            switch(str[i + 1]) {
                case 'n': 
                    sprintf(returnstring, "%s\n", returnstring); 
                    break;
                case 'r': 
                    sprintf(returnstring, "%s\r", returnstring); 
                    break;
                case 'e': 
                    sprintf(returnstring, "%s\e", returnstring); 
                    break;
            }
        } else if(str[i + 1] != '\\') {
            sprintf(returnstring, "%s%c", returnstring, str[i + 1]);
        }
    }
    sprintf(filestring, "%s", returnstring);
    return filestring;
}
char *checkifip(char *ip, char *response)
{
    char cmd[80], buffer[80];
    int status = 0;
    sprintf(cmd, "curl -s https://ipinfo.io/%s?token=80c34afef99e4e -q", ip);
    FILE *cmds = popen(cmd, "r");
    while (fgets(buffer, sizeof(buffer), cmds) != NULL)
    {
        if (strcasestr(buffer, "error"))
            status = -1;
        memset(buffer, 0, sizeof(buffer));
    }
    pclose(cmds);
    if (status == -1)
    {
        sprintf(response, "Failed");
    }
    else
    {
        sprintf(response, "Success");
    }
    return "Niggasz";
}
