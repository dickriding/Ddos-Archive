#include <sys/types.h>
int util_strlen(const char *str)
{
    if (!str)
        return 0;

    int l = 0;

    while (*str++)
        l++;

    return l;
}

int util_strcmp(char *str1, char *str2)
{
    int l1 = util_strlen(str1), l2 = util_strlen(str2);

    if (l1 != l2)
        return 1;

    while (l1--)
        if (*str1++ != *str2++)
            return 1;

    return 0;
}

void *util_memcpy(void *dest, const void *src, int len)
{
    char *d = dest;
    const char *s = src;

    while (len--)
        *d++ = *s++;

    return dest;
}

char *util_strcpy(char *dest, const char *src)
{
    return util_memcpy(dest, src, util_strlen(src) + 1);
}

char *util_strcat(char *dest, const char *src)
{
    return util_strcpy(dest + util_strlen(dest), src);
}

void *util_memset(void *dest, int val, int len)
{
    unsigned char *ptr = dest;

    while (len--)
        *ptr++ = val;

    return dest;
}

char *util_strtok_r(char *s, const char *delim, char **last) {
    int c, sc;
    char *spanp, *tok;

    if (!s && !(s = *last))
        return 0;

cont:
    c = *s++;
    for (spanp = (char *)delim; (sc = *spanp++) != 0;)
        if (c == sc)
            goto cont;

    if (!c)
    {
        *last = 0;
        return 0;
    }

    tok = s - 1;
    for (;;)
    {
        c = *s++;
        spanp = (char *)delim;

        do
        {
            if ((sc = *spanp++) == c)
            {
                if (!c)
                    s = 0;
                else
                    s[-1] = 0;

                *last = s;
                return (tok);
            }
        } while (sc != 0);
    }
}

char *util_strtok(char *s, const char *delim)
{
    static char *last;
    return util_strtok_r(s, delim, &last);
}

int util_strncmp(const char *s1, const char *s2, register int n)
{
    register unsigned char u1, u2;

    while (n--)
    {
        u1 = (unsigned char)*s1++;
        u2 = (unsigned char)*s2++;

        if (u1 != u2)
            return u1 - u2;

        if (u1 == '\0')
            return 0;
    }
    return 0;
}

char *util_strstr(const char *s, const char *find)
{
    char c, sc;
    int len;

    if ((c = *find++) != '\0')
    {
        len = util_strlen(find);
        do
        {
            do
            {
                if ((sc = *s++) == '\0')
                    return 0;
            } while (sc != c);
        } while (util_strncmp(s, find, len) != 0);
        s--;
    }
    return ((char *)s);
}
