#pragma once

void ensure(void);
void connection(char *);
