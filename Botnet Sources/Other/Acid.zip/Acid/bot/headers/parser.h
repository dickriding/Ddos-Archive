#pragma once

void parser(char *);
