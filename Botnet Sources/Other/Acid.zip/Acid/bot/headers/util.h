#pragma once

int util_strlen(const char *);
int util_strcmp(char *, char *);
void *util_memcpy(void *, const void *, int);
char *util_strcpy(char *, const char *);
char *util_strcat(char *, const char *);
void *util_memset(void *, int, int);
char *util_strtok_r(char *, const char *, char **);
char *util_strtok(char *, const char *);
int util_strncmp(const char *, const char *, register int);
char *util_strstr(const char *, const char *);
