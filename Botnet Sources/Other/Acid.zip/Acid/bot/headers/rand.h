#pragma once

void rand_alphanum(char *, int);
