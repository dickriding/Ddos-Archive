#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <time.h>

const char alphanum[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

void rand_alphanum(char *str, int len)
{
    srand(time(NULL));

    for (int l = 0; l < len; l++)
        str[l] = alphanum[rand() % (sizeof(alphanum) - 1)];

    str[len] = '\0';
#ifdef DEBUG
    printf("[rand] str (%s)\n", str);
#endif
}
