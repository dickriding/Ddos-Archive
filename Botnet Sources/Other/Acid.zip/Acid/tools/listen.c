#include <wait.h>
#include <time.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/prctl.h>
#include <arpa/inet.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <sys/socket.h>
#include <netinet/ip.h>

void main_accept(int fd) {
    while(1) {
        char buf[512];
        prctl(PR_SET_PDEATHSIG, SIGTERM);

        int afd, handler_pid = 0;
        struct sockaddr_in addr;
        socklen_t socklen = sizeof(struct sockaddr_in);

        if((afd = accept(fd, (struct sockaddr *)&addr, &socklen)) == -1)
            return;

        printf("[COMMAND] accepted connection: %s fd: %d\n", inet_ntoa(addr.sin_addr), afd);

        recv(afd, buf, sizeof(buf) - 1, 0);
        printf("%s\n", buf);
    }
}
void main_command_listener() {
    if(!fork()) {
        printf("[COMMAND] command listener started\n");
        prctl(PR_SET_PDEATHSIG, SIGTERM);

        int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        struct sockaddr_in addr;

        addr.sin_addr.s_addr = inet_addr("0.0.0.0");
        addr.sin_port = htons(55559);
        addr.sin_family = AF_INET;

        bind(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
        listen(sock, 9);

        main_accept(sock);
    }
}
int main() {
    main_command_listener();
}
